package hu.bme.aut.android.cocktailcraft.data

interface OnItemClickListener {
        
    fun onItemClick(position: Int)
    }