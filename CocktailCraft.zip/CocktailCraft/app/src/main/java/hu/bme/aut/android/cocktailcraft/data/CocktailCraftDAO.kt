package hu.bme.aut.android.cocktailcraft.data

import androidx.room.*


@Dao
interface CocktailCraftDAO {

    @Query("SELECT * FROM cocktail")
    suspend fun getAllCocktails(): List<Cocktail>

    @Query("SELECT * FROM cocktail WHERE cocktail.id = :cocktailId")
    suspend fun getCocktail(cocktailId: Long): Cocktail

    @Insert
    suspend fun insertCocktail(item: Cocktail): Long

    @Update
    suspend fun updateCocktail(item: Cocktail)

    @Delete
    suspend fun deleteCocktail(item: Cocktail)

    @Query("SELECT * FROM ingredient WHERE cocktailId = :cocktailId")
    suspend fun getAllIngredients(cocktailId: Long): List<Ingredient>

    @Insert
    suspend fun insertIngredient(item: Ingredient): Long

    @Update
    suspend fun updateIngredient(item: Ingredient)

    @Delete
    suspend fun deleteIngredient(item: Ingredient)

    @Query("DELETE FROM ingredient WHERE ingredient.cocktailId = :cocktailId")
    suspend fun deleteIngredientsOfCocktail(cocktailId: Long)

    @Query("DELETE FROM ingredient WHERE ingredient.id = :id")
    suspend fun deleteIngredientViaId(id: Long)







}