package hu.bme.aut.android.cocktailcraft

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.cocktailcraft.adapter.IngredientAdapter
import hu.bme.aut.android.cocktailcraft.adapter.OnItemClickListener
import hu.bme.aut.android.cocktailcraft.data.CocktailCraftDatabase
import hu.bme.aut.android.cocktailcraft.data.Ingredient
import hu.bme.aut.android.cocktailcraft.databinding.ActivityIngredientsBinding
import hu.bme.aut.android.cocktailcraft.fragments.EditIngredientDialogFragment
import hu.bme.aut.android.cocktailcraft.fragments.NewIngredientDialogFragment
import kotlinx.coroutines.*

class IngredientsActivity : AppCompatActivity(), CoroutineScope by MainScope(),
    IngredientAdapter.IngredientItemClickListener,
    NewIngredientDialogFragment.NewIngredientDialogListener,
    EditIngredientDialogFragment.EditIngredientDialogListener {

    private lateinit var binding: ActivityIngredientsBinding
    private lateinit var adapter: IngredientAdapter
    private lateinit var database: CocktailCraftDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIngredientsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = CocktailCraftDatabase.getDatabase(applicationContext)

        initRecyclerView()

        binding.tvAdd.setOnClickListener {
            NewIngredientDialogFragment().show(supportFragmentManager, NewIngredientDialogFragment.TAG)
        }

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        adapter.setItemClickListener(object: OnItemClickListener{
            override fun onItemClick(position: Int) {
                val editIngredientBundle = Bundle()
                val ingredient = adapter.getItem(position)
                editIngredientBundle.putInt("itemPosition", position)
                editIngredientBundle.putString("name", ingredient.name)
                editIngredientBundle.putInt("alcoholPercentages", ingredient.alcoholPercentages)
                editIngredientBundle.putBoolean("alcoholic", ingredient.alcoholic)
                editIngredientBundle.putInt("amount", ingredient.amount)
                editIngredientBundle.putInt("uom", ingredient.unitOfMeasure.ordinal)
                val editDialog = EditIngredientDialogFragment()
                editDialog.arguments = editIngredientBundle
                editDialog.show(supportFragmentManager, EditIngredientDialogFragment.TAG)
            }
        })
    }
    private fun initRecyclerView() {
        adapter = IngredientAdapter(this)
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()

        var itemTouchHelper = ItemTouchHelper(SwipeToDeleteGesture())
        itemTouchHelper.attachToRecyclerView(binding.rvMain)

    }

    private fun loadItemsInBackground() = launch {
        val items = withContext(Dispatchers.IO) {
            database.cocktailCraftDao().getAllIngredients(intent.getLongExtra("cocktailId", 0))
        }
        adapter.update(items)
    }

    override fun onItemChanged(item: Ingredient) {
        updateItemInBackground(item)
    }

    private fun updateItemInBackground(item: Ingredient) = launch {
        withContext(Dispatchers.IO) {
            database.cocktailCraftDao().updateIngredient(item)
        }
        loadItemsInBackground()

    }

    override fun onItemRemoved(item: Ingredient) {
        removeItemsInBackground(item)
    }

    private fun removeItemsInBackground(item: Ingredient) = launch {
        withContext(Dispatchers.IO) {
            database.cocktailCraftDao().deleteIngredient(item)
        }
        adapter.removeItem(item)
    }

    override fun onIngredientCreated(item: Ingredient) {
        addItemBackground(item)
    }

    private fun addItemBackground(item: Ingredient) = launch {
        var id: Long = 0
        item.cocktailId = intent.getLongExtra("cocktailId", 0)
        withContext(Dispatchers.IO) {
            id = database.cocktailCraftDao().insertIngredient(item)
        }
        item.id = id
        adapter.addItem(item)
    }

    inner class SwipeToDeleteGesture : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            return false
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            var pos: Int = viewHolder.adapterPosition
            var ingredient: Ingredient = adapter.getItem(pos)
            removeItemsInBackground(ingredient)

        }

    }

    override fun onIngredientUpdated(itemPosition: Int?, edited: Ingredient) {
        var old = adapter.getItem(itemPosition!!)
        old.name = edited.name
        old.amount = edited.amount
        old.alcoholic = edited.alcoholic
        if (old.alcoholic) {
            old.alcoholPercentages = edited.alcoholPercentages
        } else {
            old.alcoholPercentages = 0
        }
        old.unitOfMeasure = edited.unitOfMeasure
        onItemChanged(old)
    }


}