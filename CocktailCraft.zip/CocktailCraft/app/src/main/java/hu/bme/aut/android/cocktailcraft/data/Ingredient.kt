package hu.bme.aut.android.cocktailcraft.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "ingredient")
class Ingredient (
    @ColumnInfo(name = "cocktailId") var cocktailId: Long = 0,
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long = 0,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "amount")var amount: Int = 0,
    @ColumnInfo(name = "alcoholic")var alcoholic: Boolean,
    @ColumnInfo(name = "unitOfMeasure")var unitOfMeasure: UnitOfMeasure,
    @ColumnInfo(name = "alcoholPercentages")var alcoholPercentages: Int = 0)