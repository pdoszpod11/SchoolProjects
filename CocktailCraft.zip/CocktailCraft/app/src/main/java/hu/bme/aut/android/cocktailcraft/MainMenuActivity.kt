package hu.bme.aut.android.cocktailcraft

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hu.bme.aut.android.cocktailcraft.adapter.IngredientAdapter
import hu.bme.aut.android.cocktailcraft.data.CocktailCraftDatabase
import hu.bme.aut.android.cocktailcraft.databinding.ActivityMainMenuBinding
import kotlin.system.exitProcess

class MainMenuActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_CocktailCraft)

        super.onCreate(savedInstanceState)
        binding = ActivityMainMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCraft.setOnClickListener {
            val craftIntent = Intent(this, CraftActivity::class.java)
            startActivity(craftIntent)
        }

        binding.btnCocktails.setOnClickListener {
            val cocktailIntent = Intent(this, CocktailActivity::class.java)
            startActivity(cocktailIntent)
        }

        binding.btnExit.setOnClickListener {
            finishAndRemoveTask()
        }


    }
}