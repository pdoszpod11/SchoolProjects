package hu.bme.aut.android.cocktailcraft.data

class CocktailStrengthCalculator {

    companion object {
        fun categorizeCocktail(strengthValue: Int) : CocktailStrength {

            return when (strengthValue) {
                0 -> CocktailStrength.ALCOHOLFREE
                in 1..3000 -> CocktailStrength.LIGHT
                in 3100..6000 -> CocktailStrength.MEDIUM
                else -> CocktailStrength.STRONG
            }

        }

        fun calculateStrength(ingredientList: List<Ingredient>): Int {
            var strengthValue = 0
            for (ingredient in ingredientList) {
                if (ingredient.alcoholic) {
                    strengthValue += ingredient.amount * ingredient.alcoholPercentages
                }
            }
            return strengthValue
        }
    }
}