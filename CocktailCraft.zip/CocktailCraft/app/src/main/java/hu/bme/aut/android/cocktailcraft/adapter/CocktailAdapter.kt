package hu.bme.aut.android.cocktailcraft.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.cocktailcraft.R
import hu.bme.aut.android.cocktailcraft.data.Cocktail
import hu.bme.aut.android.cocktailcraft.data.CocktailStrength
import hu.bme.aut.android.cocktailcraft.databinding.SimpleCocktailBinding

class CocktailAdapter:
    RecyclerView.Adapter<CocktailAdapter.CocktailViewHolder>() {

    private val items = mutableListOf<Cocktail>()
    private lateinit var itemClickListener: OnItemClickListener

    fun setItemClickListener(clickListener: OnItemClickListener) {

        itemClickListener = clickListener

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CocktailViewHolder =
        (CocktailViewHolder(SimpleCocktailBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false), itemClickListener)
        )

    override fun getItemCount(): Int = items.size

    inner class CocktailViewHolder(val binding: SimpleCocktailBinding, clickListener: OnItemClickListener) :
            RecyclerView.ViewHolder(binding.root) {
        init {
            itemView.setOnClickListener {
                clickListener.onItemClick(adapterPosition)
            }
        }
    }

    fun getItem(pos: Int) : Cocktail {
        return items[pos]
    }

    fun update(cocktails: List<Cocktail>) {
        items.clear()
        items.addAll(cocktails)
        notifyDataSetChanged()
    }



    override fun onBindViewHolder(holder: CocktailViewHolder, position: Int) {
        val cocktail = items[position]

        holder.binding.tvName.text = cocktail.name
        holder.binding.ivStrength
        holder.binding.ivStrength.setImageResource(getImageResource(cocktail.strength))

    }

    @DrawableRes
    private fun getImageResource(strength: CocktailStrength): Int {
        return when (strength) {
            CocktailStrength.ALCOHOLFREE -> R.drawable.bottles0
            CocktailStrength.LIGHT -> R.drawable.bottles1
            CocktailStrength.MEDIUM -> R.drawable.bottles2
            CocktailStrength.STRONG -> R.drawable.bottles3

        }
    }


}