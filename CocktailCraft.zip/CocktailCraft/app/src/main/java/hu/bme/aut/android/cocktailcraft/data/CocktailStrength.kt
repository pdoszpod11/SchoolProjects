package hu.bme.aut.android.cocktailcraft.data

import androidx.room.TypeConverter

enum class CocktailStrength {
    ALCOHOLFREE, LIGHT, MEDIUM, STRONG;

    companion object {


        @TypeConverter
        @JvmStatic
        fun getByOrdinal(ordinal: Int): CocktailStrength? {
            for (strength in values()) {
                if (strength.ordinal == ordinal) {
                    return strength
                }
            }
            return null
        }

        @TypeConverter
        @JvmStatic
        fun toInt(strength: CocktailStrength): Int {
            return strength.ordinal
        }

    }
}