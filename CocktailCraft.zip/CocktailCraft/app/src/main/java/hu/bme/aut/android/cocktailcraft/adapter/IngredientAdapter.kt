package hu.bme.aut.android.cocktailcraft.adapter


import android.opengl.Visibility
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.cocktailcraft.data.Ingredient
import android.view.LayoutInflater
import android.view.View
import androidx.recyclerview.widget.ItemTouchHelper
import hu.bme.aut.android.cocktailcraft.databinding.IngredientBinding


class IngredientAdapter(private val listener: IngredientItemClickListener):
    RecyclerView.Adapter<IngredientAdapter.IngredientViewHolder>() {

    private val items = mutableListOf<Ingredient>()
    private lateinit var itemClickListener: OnItemClickListener

    fun setItemClickListener(clickListener: OnItemClickListener) {

        itemClickListener = clickListener

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        (IngredientViewHolder(IngredientBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false), itemClickListener)
        )

    override fun onBindViewHolder(holder: IngredientAdapter.IngredientViewHolder, position: Int) {
        val ingredient = items[position]

        holder.binding.cbIsAlcoholic.isChecked = ingredient.alcoholic
        holder.binding.tvIngredientName.text = "${ingredient.name}"
        holder.binding.tvAmount.text = "${ingredient.amount} " + "${ingredient.unitOfMeasure}"
        holder.binding.tvAlcoholPercentage.text = "${ingredient.alcoholPercentages}"

        holder.binding.cbIsAlcoholic.setOnCheckedChangeListener { buttonView, isChecked ->
            ingredient.alcoholic = isChecked
            listener.onItemChanged(ingredient)
        }

        holder.binding.ibRemove.setOnClickListener {
            listener.onItemRemoved(ingredient)
        }

        if (holder.binding.cbIsAlcoholic.isChecked) {
            holder.binding.llPercentage.visibility = View.VISIBLE
        }
    }

    override fun getItemCount(): Int = items.size



    interface IngredientItemClickListener {
        fun onItemChanged(item: Ingredient)
        fun onItemRemoved(item: Ingredient)

    }

    inner class IngredientViewHolder(val binding: IngredientBinding, clickListener: OnItemClickListener) :
            RecyclerView.ViewHolder(binding.root) {

        init {
            itemView.setOnClickListener {
                clickListener.onItemClick(adapterPosition)
            }
        }
    }

    fun addItem(item: Ingredient) {
        items.add(item)
        notifyItemInserted(items.size-1)
    }

    fun update(ingredients: List<Ingredient>) {
        items.clear()
        items.addAll(ingredients)
        notifyDataSetChanged()
    }

    fun removeItem(item: Ingredient) {
        var idx = items.indexOf(item)
        items.remove(item)
        notifyItemRemoved(idx)
    }

    fun getItem(pos: Int) : Ingredient {
        return items[pos]
    }




}