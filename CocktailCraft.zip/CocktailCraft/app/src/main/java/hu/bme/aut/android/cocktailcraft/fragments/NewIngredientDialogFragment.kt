package hu.bme.aut.android.cocktailcraft.fragments

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import hu.bme.aut.android.cocktailcraft.R
import hu.bme.aut.android.cocktailcraft.data.Ingredient
import hu.bme.aut.android.cocktailcraft.data.UnitOfMeasure
import hu.bme.aut.android.cocktailcraft.databinding.DialogNewIngredientBinding

open class NewIngredientDialogFragment : DialogFragment() {

    companion object {
        const val TAG = "NewIngredientDialogFragment"
    }

    private lateinit var listener: NewIngredientDialogListener

    private var _binding: DialogNewIngredientBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activity: FragmentActivity = requireActivity()!!
        listener = if (activity is NewIngredientDialogListener) {
            activity
        } else {
            throw RuntimeException("Activity must implement the NewIngredientDialogListener interface!")
        }

    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogNewIngredientBinding.inflate(LayoutInflater.from(context))

        binding.spUnitOfMeasure.adapter = ArrayAdapter(
            requireContext()!!,
            android.R.layout.simple_spinner_dropdown_item,
            resources.getStringArray(R.array.unit_of_measure_dimensions)
        )

        binding.cbIsAlcoholic.setOnClickListener {
            if (binding.cbIsAlcoholic.isChecked) {
                binding.llPercentage.visibility = View.VISIBLE
            } else {
                binding.llPercentage.visibility = View.GONE
            }
        }



        return AlertDialog.Builder(requireActivity())
            .setView(binding.root)
            .setPositiveButton(R.string.ok) { dialogInterface, i ->
                if (isValid()) {
                    listener.onIngredientCreated(getIngredient())
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
    }

    private fun getIngredient(): Ingredient {
        return Ingredient(
            name = binding.etName.text.toString(),
            amount = binding.etAmount.text.toString().toIntOrNull() ?:0,
            alcoholic = binding.cbIsAlcoholic.isChecked,
            alcoholPercentages = binding.etAlcoholPercentage.text.toString().toIntOrNull() ?:0,
            unitOfMeasure = UnitOfMeasure.getByOrdinal(binding.spUnitOfMeasure.selectedItemPosition)
                ?: UnitOfMeasure.ML
        )


    }

    private fun isValid(): Boolean {
        return binding.etName.text.isNotEmpty()
    }

    interface NewIngredientDialogListener {
        fun onIngredientCreated(item: Ingredient)
    }
}