package hu.bme.aut.android.cocktailcraft.data

import android.content.Context
import androidx.room.*


@Database(entities = [
    Cocktail::class,
    Ingredient::class],
    version = 16)
@TypeConverters(value = [CocktailStrength::class, UnitOfMeasure::class])
abstract class CocktailCraftDatabase: RoomDatabase() {

    companion object {
        fun getDatabase(applicationContext: Context): CocktailCraftDatabase {
            return Room.databaseBuilder(
                applicationContext,
                CocktailCraftDatabase::class.java,
                "cocktail-craft"
            ).fallbackToDestructiveMigration()
                .build()
        }
    }

    abstract fun cocktailCraftDao(): CocktailCraftDAO
}

