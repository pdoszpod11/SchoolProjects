package hu.bme.aut.android.cocktailcraft.data

import androidx.room.TypeConverter

enum class UnitOfMeasure {
    PCS, ML, MG;

    companion object {


        @TypeConverter
        @JvmStatic
        fun getByOrdinal(ordinal: Int): UnitOfMeasure? {
            for (uom in values()) {
                if (uom.ordinal == ordinal) {
                    return uom
                }
            }
            return null
        }

        @TypeConverter
        @JvmStatic
        fun toInt(uom: UnitOfMeasure): Int {
            return uom.ordinal
        }

    }
}