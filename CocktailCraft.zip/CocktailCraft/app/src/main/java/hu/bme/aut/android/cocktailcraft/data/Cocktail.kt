package hu.bme.aut.android.cocktailcraft.data

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "cocktail")
class Cocktail(
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long = 0,
    @ColumnInfo(name = "name") var name: String = "",
    @ColumnInfo(name = "strength") var strength: CocktailStrength = CocktailStrength.ALCOHOLFREE
//    @ColumnInfo(name = "description") var description: String = "",
)