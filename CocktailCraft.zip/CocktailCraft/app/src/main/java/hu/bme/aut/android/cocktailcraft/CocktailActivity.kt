package hu.bme.aut.android.cocktailcraft

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.cocktailcraft.adapter.CocktailAdapter
import hu.bme.aut.android.cocktailcraft.adapter.OnItemClickListener
import hu.bme.aut.android.cocktailcraft.data.CocktailCraftDatabase
import hu.bme.aut.android.cocktailcraft.databinding.ActivityCocktailBinding
import kotlinx.coroutines.*

class CocktailActivity : AppCompatActivity(), CoroutineScope by MainScope() {

    private lateinit var binding: ActivityCocktailBinding
    private lateinit var adapter: CocktailAdapter
    private lateinit var database: CocktailCraftDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCocktailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = CocktailCraftDatabase.getDatabase(applicationContext)

        initRecyclerView()

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        val detailedCocktailIntent = Intent(this, DetailedCocktailActivity::class.java)

        adapter.setItemClickListener(object : OnItemClickListener{
            override fun onItemClick(position: Int) {
                //Toast.makeText(this@CocktailActivity, "Clicked: ${adapter.getItem(position).name}", Toast.LENGTH_SHORT).show()
                detailedCocktailIntent.putExtra("cocktailId", adapter.getItem(position).id)
                detailedCocktailIntent.putExtra("cocktailName", adapter.getItem(position).name)
                detailedCocktailIntent.putExtra("cocktailStrength", adapter.getItem(position).strength.ordinal)

                startActivity(detailedCocktailIntent)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        loadItemsInBackground()
    }


    private fun initRecyclerView() {
        adapter = CocktailAdapter()
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }

    private fun loadItemsInBackground() = launch {
        val items = withContext(Dispatchers.IO) {
            database.cocktailCraftDao().getAllCocktails()
        }
        adapter.update(items)
    }
}