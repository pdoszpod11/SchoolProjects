package hu.bme.aut.android.cocktailcraft.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.cocktailcraft.data.Ingredient
import hu.bme.aut.android.cocktailcraft.databinding.IngredientInCocktailBinding

class DetailedCocktailAdapter:
RecyclerView.Adapter<DetailedCocktailAdapter.DetailedCocktailViewHolder>() {

    private val items = mutableListOf<Ingredient>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        DetailedCocktailViewHolder(IngredientInCocktailBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false)
        )

    override fun onBindViewHolder(holder: DetailedCocktailAdapter.DetailedCocktailViewHolder, position: Int) {
        val ingredient = items[position]

        holder.binding.tvName.text = "${ingredient.name}"
        holder.binding.tvAmount.text = "${ingredient.amount}"
        holder.binding.tvUnitOfMeasure.text = "${ingredient.unitOfMeasure}"

        if (ingredient.alcoholic) {
            holder.binding.tvAlcoholPercentage.text = "${ingredient.alcoholPercentages} %"
        } else {
            holder.binding.tvAlcoholPercentage.text = ""
        }

    }

    fun update(ingredients: List<Ingredient>) {
        items.clear()
        items.addAll(ingredients)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    inner class DetailedCocktailViewHolder(val binding: IngredientInCocktailBinding) :
        RecyclerView.ViewHolder(binding.root) {}
}



