package hu.bme.aut.android.cocktailcraft.data

import android.content.Context
import hu.bme.aut.android.cocktailcraft.data.CocktailStrengthCalculator.Companion.calculateStrength
import hu.bme.aut.android.cocktailcraft.data.CocktailStrengthCalculator.Companion.categorizeCocktail
import kotlinx.coroutines.*


class CocktailRepository(applicationContext: Context) : CoroutineScope by MainScope(){

    private var database: CocktailCraftDatabase = CocktailCraftDatabase.getDatabase(applicationContext)

    fun addItemBackground(item: Cocktail) = launch {
        var id: Long = 0
        withContext(Dispatchers.IO) {
            id = database.cocktailCraftDao().insertCocktail(item)
        }
        item.id = id
    }

    fun removeItemBackground(item: Cocktail) = launch {
        withContext(Dispatchers.IO) {
            removeIngredientsBackground(item)
            database.cocktailCraftDao().deleteCocktail(item)
        }
    }

    private fun updateItemInBackground(item: Cocktail) = launch {
        withContext(Dispatchers.IO) {
            database.cocktailCraftDao().updateCocktail(item)

        }
    }

    private fun removeIngredientsBackground(item: Cocktail) = launch {
        withContext(Dispatchers.IO) {
            database.cocktailCraftDao().deleteIngredientsOfCocktail(item.id)
        }
    }

    fun saveCocktailChanges(item: Cocktail) = launch {
        var ingreds = withContext(Dispatchers.IO) {
            database.cocktailCraftDao().getAllIngredients(item.id)
        }
        var strength = categorizeCocktail(calculateStrength(ingreds))
        item.strength = strength
        updateItemInBackground(item)
    }
}