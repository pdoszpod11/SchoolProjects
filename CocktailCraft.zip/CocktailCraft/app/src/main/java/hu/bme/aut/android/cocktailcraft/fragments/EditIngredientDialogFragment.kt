package hu.bme.aut.android.cocktailcraft.fragments

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import hu.bme.aut.android.cocktailcraft.R
import hu.bme.aut.android.cocktailcraft.data.CocktailCraftDatabase
import hu.bme.aut.android.cocktailcraft.data.Ingredient
import hu.bme.aut.android.cocktailcraft.data.UnitOfMeasure
import hu.bme.aut.android.cocktailcraft.databinding.DialogEditIngredientBinding
import hu.bme.aut.android.cocktailcraft.databinding.DialogNewIngredientBinding

open class EditIngredientDialogFragment : DialogFragment() {

    companion object {
        const val TAG = "EditIngredientDialogFragment"
    }

    private lateinit var listener: EditIngredientDialogListener

    private var _binding: DialogEditIngredientBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activity: FragmentActivity = requireActivity()!!
        listener = if (activity is EditIngredientDialogListener) {
            activity
        } else {
            throw RuntimeException("Activity must implement the NewIngredientDialogListener interface!")
        }

    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogEditIngredientBinding.inflate(LayoutInflater.from(context))

        val mBundle = arguments
        val itemPosition = mBundle?.getInt("itemPosition")

        if (mBundle?.getBoolean("alcoholic")!!) {
            binding.llPercentage.visibility = View.VISIBLE
        }

        binding.spUnitOfMeasure.adapter = ArrayAdapter(
            requireContext()!!,
            android.R.layout.simple_spinner_dropdown_item,
            resources.getStringArray(R.array.unit_of_measure_dimensions)
        )

        binding.cbIsAlcoholic.setOnClickListener {
            if (binding.cbIsAlcoholic.isChecked) {
                binding.llPercentage.visibility = View.VISIBLE
            } else {
                binding.llPercentage.visibility = View.GONE
            }
        }
        binding.etName.setText(mBundle?.getString("name"))
        binding.cbIsAlcoholic.isChecked = mBundle?.getBoolean("alcoholic")!!
        binding.etAlcoholPercentage.setText(mBundle.getInt("alcoholPercentages").toString())
        binding.etAmount.setText(mBundle.getInt("amount").toString())
        binding.spUnitOfMeasure.setSelection(mBundle.getInt("uom"))

        return AlertDialog.Builder(requireActivity())
            .setView(binding.root)
            .setPositiveButton(R.string.ok) { dialogInterface, i ->
                if (isValid()) {
                    listener.onIngredientUpdated(itemPosition, getIngredient())
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
    }

    private fun getIngredient(): Ingredient {
        return Ingredient(
            name = binding.etName.text.toString(),
            amount = binding.etAmount.text.toString().toIntOrNull() ?:0,
            alcoholic = binding.cbIsAlcoholic.isChecked,
            alcoholPercentages = binding.etAlcoholPercentage.text.toString().toIntOrNull() ?:0,
            unitOfMeasure = UnitOfMeasure.getByOrdinal(binding.spUnitOfMeasure.selectedItemPosition)
                ?: UnitOfMeasure.ML
        )
    }

    private fun isValid(): Boolean {
        return binding.etName.text.isNotEmpty()
    }

    interface EditIngredientDialogListener {
        fun onIngredientUpdated(itemPosition: Int?, edited: Ingredient)
    }
}