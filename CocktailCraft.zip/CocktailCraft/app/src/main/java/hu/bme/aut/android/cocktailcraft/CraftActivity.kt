package hu.bme.aut.android.cocktailcraft

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hu.bme.aut.android.cocktailcraft.data.*
import hu.bme.aut.android.cocktailcraft.databinding.ActivityCraftBinding


class CraftActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCraftBinding
    private lateinit var cocktailRepo: CocktailRepository
    private lateinit var cocktail: Cocktail

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCraftBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cocktailRepo = CocktailRepository(applicationContext)

        cocktail = createCocktail()
        cocktailRepo.addItemBackground(cocktail)

        binding.btnSave.setOnClickListener {
            validityCheck()
        }

        binding.btnIngredients.setOnClickListener {
            val ingredientsIntent = Intent(this, IngredientsActivity::class.java)
            ingredientsIntent.putExtra("cocktailId", cocktail.id)
            startActivity(ingredientsIntent)
        }

        binding.btnBack.setOnClickListener {
            if (checkName()) {
                cocktailRepo.removeItemBackground(cocktail)
            } else {
                cocktail.name = binding.etName.text.toString()
                updateCocktail()
            }
            onBackPressed()
        }
    }

    private fun validityCheck() {
        if (checkName()) {
            binding.etName.requestFocus()
            binding.etName.error = "Please name your cocktail!"
        } else {
            cocktail.name = binding.etName.text.toString()
            updateCocktail()
            onBackPressed()
        }

    }

    private fun createCocktail() : Cocktail {
        return Cocktail(name = binding.etName.text.toString())
    }

    private fun checkName() : Boolean {
        return binding.etName.text.toString().isEmpty()
    }

    private fun updateCocktail() {
        cocktailRepo.saveCocktailChanges(cocktail)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (checkName()) {
            cocktailRepo.removeItemBackground(cocktail)
        }
    }


}