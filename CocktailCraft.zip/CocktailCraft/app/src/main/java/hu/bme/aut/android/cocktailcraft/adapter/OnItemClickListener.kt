package hu.bme.aut.android.cocktailcraft.adapter

interface OnItemClickListener {

        fun onItemClick(position: Int)
    }