package hu.bme.aut.android.cocktailcraft

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.cocktailcraft.adapter.DetailedCocktailAdapter
import hu.bme.aut.android.cocktailcraft.data.*
import hu.bme.aut.android.cocktailcraft.data.CocktailStrengthCalculator.Companion.calculateStrength
import hu.bme.aut.android.cocktailcraft.data.CocktailStrengthCalculator.Companion.categorizeCocktail
import hu.bme.aut.android.cocktailcraft.databinding.ActivityDetailedCocktailBinding
import hu.bme.aut.android.cocktailcraft.databinding.DialogEditNameBinding
import hu.bme.aut.android.cocktailcraft.databinding.DialogNewIngredientBinding
import kotlinx.coroutines.*

class DetailedCocktailActivity : AppCompatActivity(), CoroutineScope by MainScope() {

    private lateinit var binding: ActivityDetailedCocktailBinding
    private lateinit var adapter: DetailedCocktailAdapter
    private lateinit var database: CocktailCraftDatabase
    private lateinit var repository: CocktailRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailedCocktailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var cocktailId = intent.getLongExtra("cocktailId",0)

        database = CocktailCraftDatabase.getDatabase(applicationContext)
        repository = CocktailRepository(applicationContext)

        initRecyclerView()

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        binding.ibEditName.setOnClickListener {
            editNameDialog().show()
        }


        binding.ibEditIngredients.setOnClickListener {
            val ingredientsIntent = Intent(this, IngredientsActivity::class.java)
            ingredientsIntent.putExtra("cocktailId", cocktailId)
            startActivity(ingredientsIntent)
        }

        binding.tvDelete.setOnClickListener {
            deleteCocktailInBackground(cocktailId)
            onBackPressed()
        }
    }

    private fun editNameDialog(): AlertDialog {
        var dialogBinding = DialogEditNameBinding.inflate(layoutInflater)
        val builder = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.ok) { dialogInterface, i ->
                if (dialogBinding.etName.text.toString().isNotEmpty()) {
                    binding.tvName.text = dialogBinding.etName.text.toString()
                    setNameOfCocktail()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .create()
        return builder
    }

    override fun onResume() {
        super.onResume()
        updateItemInBackground(intent.getLongExtra("cocktailId", 0))
        loadItemsInBackground()

    }

    private fun initRecyclerView() {
        adapter = DetailedCocktailAdapter()
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        binding.tvName.text = intent.getStringExtra("cocktailName")
        loadItemsInBackground()


    }

    private fun setNameOfCocktail() = launch {
        var cocktail = withContext(Dispatchers.IO) {
            database.cocktailCraftDao().getCocktail(intent.getLongExtra("cocktailId", 0))
        }
        cocktail.name = binding.tvName.text.toString()
        repository.saveCocktailChanges(cocktail)
    }

    private fun loadItemsInBackground() = launch {
        val items = withContext(Dispatchers.IO) {
            database.cocktailCraftDao().getAllIngredients(intent.getLongExtra("cocktailId", 0))
        }
        adapter.update(items)
        var strength = calculateStrength(items)
        binding.ivStrength.setImageResource(getImageResource(categorizeCocktail(strength)))

    }

    private fun deleteCocktailInBackground(cocktailId: Long) = launch {
        withContext(Dispatchers.IO) {
            database.cocktailCraftDao().deleteCocktail(database.cocktailCraftDao().getCocktail(cocktailId))
            database.cocktailCraftDao().deleteIngredientsOfCocktail(cocktailId)
        }
    }

    private fun updateItemInBackground(cocktailId: Long) = launch {
        var cocktail = withContext(Dispatchers.IO) {
             database.cocktailCraftDao().getCocktail(cocktailId)
        }
        repository.saveCocktailChanges(cocktail)

    }

    @DrawableRes
    private fun getImageResource(strength: CocktailStrength): Int {
        return when (strength) {
            CocktailStrength.ALCOHOLFREE -> R.drawable.bottles0
            CocktailStrength.LIGHT -> R.drawable.bottles1
            CocktailStrength.MEDIUM -> R.drawable.bottles2
            CocktailStrength.STRONG -> R.drawable.bottles3

        }
    }
}